<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('apellidopaterno');
            $table->string('apellidomaterno');
            $table->date('fecha_nac');
            $table->string('email')->unique();
            $table->string('password');
            $table->string('provider');
            $table->string('provider_id');
            $table->unsignedInteger('imccrs_id');
            $table->foreign('imccrs_id')->references('id')->on('imccrs');
            $table->unsignedInteger('encuesta1_id');
            $table->foreign('encuesta1_id')->references('id')->on('encuesta1s');
            $table->unsignedInteger('encuesta2_id');
            $table->foreign('encuesta2_id')->references('id')->on('encuesta2s');
            $table->unsignedInteger('encuesta3_id');
            $table->foreign('encuesta3_id')->references('id')->on('encuesta3s');
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
