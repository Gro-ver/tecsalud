<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEncuesta1sTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('encuesta1s', function (Blueprint $table) {
            $table->increments('id');
            $table->double('p1',6,3);
            $table->double('p2',6,3);
            $table->double('p3',6,3);
            $table->double('p4',6,3);
            $table->double('p5',6,3);
            $table->double('p6',6,3);
            $table->double('p7',6,3);
            $table->double('p8',6,3);
            $table->double('p9',6,3);
            $table->double('p10',6,3);
            $table->double('p11',6,3);
            $table->double('p12',6,3);
            $table->double('p13',6,3);
            $table->double('p14',6,3);
            $table->double('p15',6,3);
            $table->double('p16',6,3);
            $table->double('p17',6,3);
            $table->double('p18',6,3);
            $table->double('p19',6,3);
            $table->double('p20',6,3);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('encuesta1s');
    }
}
