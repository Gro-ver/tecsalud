<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Encuesta1;
use App\Encuesta2;
use App\Encuesta3;
class EncuestasController extends Controller
{
    
    
     public function store(Request $request)
    {
        // Validate the request...

        $encuesta1 = new Encuesta1;

        $encuesta1->p1 = $request->p1;
        $encuesta1->p2 = $request->p2;
        $encuesta1->p3 = $request->p3;
        $encuesta1->p4 = $request->p4;
        $encuesta1->p5 = $request->p5;
        $encuesta1->p6 = $request->p6;
        $encuesta1->p7 = $request->p7;
        $encuesta1->p8 = $request->p8;
        $encuesta1->p9 = $request->p9;
        $encuesta1->p10 = $request->p10;
        $encuesta1->p11 = $request->p11;
        $encuesta1->p12 = $request->p12;
        $encuesta1->p13 = $request->p13;
        $encuesta1->p14 = $request->p14;
        $encuesta1->p15 = $request->p15;
        $encuesta1->p16 = $request->p16;
        $encuesta1->p17 = $request->p17;
        $encuesta1->p18 = $request->p18;
        $encuesta1->p19 = $request->p19;
        $encuesta1->p20 = $request->p20;
        $encuesta1->save();
    }
    
    public function encuesta1()
    {
        return view('encuesta');
    }
    
}


