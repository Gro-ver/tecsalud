<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Encuesta3 extends Model
{
    //
}
