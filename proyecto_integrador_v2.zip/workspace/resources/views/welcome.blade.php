
<html lang="{{ app()->getLocale() }}">
    
  
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>TecSalud</title>
        
        

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
              
             content: "";
             background: url(http://www.myhealthplans.es/assets/img/slider/7.jpg);
             opacity: 0.95;
             top: 0;
             left: 0;
             bottom: 0;
             right: 0;
             position: absolute;
             z-index: -1; 
             
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
            .content{
               border: black 2px solid;
               background:White;
               
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
                    @else
                       
                      <a href="{{ route('login') }}"> <button type="button" class="btn btn-info btn-lg" >Login</button></a>
                      <a href="{{ route('register') }}"> <button type="button" class="btn btn-info btn-lg" >registrarse</button></a>
                          <!--calcular  imc!-->
               
                        <!--pedir cita!-->
                           <button type="button" class="btn btn-info btn-lg" data-toggle="modal2" data-target="#mmodal2">cita   gratis</button>
                    @endauth
                </div>
            @endif

            <div class="content">
                <div class="title m-b-md">
                   TecSalud
                </div>
               <html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
 
  .modal-footer {
      background-color: #f9f9f9;
  }
  </style>
</head>
<body>

<div class="container"  id="formulario">
  

    
    
         
          <h4><span class="glyphicon glyphicon"></span> Indice de masa  Corporal (IMC)</h4>
        
        <div class="modal-body" >
          <form class="form-horizontal">

               

    <div class="form-group" >
      <label class="col-xs-6 col-sm-4" for="kilos">Peso(kg):</label>
      <div class="col-sm-10">
        <input type="number" name="kilos" class="form-control" id="kilos" placeholder="ingrese su peso">
      </div>
    </div>
    <div class="form-group">
      <label class="col-xs-6 col-sm-4"  required>talla(cm):</label>
      <div class="col-sm-10" for="metros">          
        <input type="number"for="metros" class="form-control" id="metros" name="metros" placeholder="metros" required>
        <input type="number"for="centimetros" class="form-control" id="metros" name="centrimetros" placeholder="centrimetros" required>
      </div>
    </div>
    <div class="form-group">        
      <div class="col-xs-6 col-sm-4">
        <label class="control-label col-sm-2" for="sex"> genero</label>
        <div class="radio-group" value="sexo">
            <label><input type="radio" name="radio" value="femenino" required>femenino</label>
            <label><input type="radio" name="radio" value="masculino" required> masculino</label>
        </div>
      </div>
 
    </div>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
    <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">calcular imc</button>
      <a href="{{ route('register') }}"> <button type="button" class="btn btn-info btn-lg" >registrarse</button></a>
      </div>
    </div>
  </form>
          
        <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
       
        <div class="modal-body" >
          <p> <h2>TU ÍNDICE DE MASA CORPORAL</h2> <br>
             El Índice de Masa Corporal (IMC) es un indicador útil que se obtiene del peso y la estatura. Permite establecer rangos de peso recomendado. 
            
             Importante: El IMC no determina el porcentaje de grasa corporal. Para una evaluación de sobrepeso u obesidad hay que tomar en cuenta otros parámetros clínicos.</p>
          <hr>
          <div> tu imc es de :
                 
                <script type="text/javascript">
        function calcular(){
    		// pegando o id do formulario
    		var formulario = document.getElementById("formulario");	
    		
    		// kilos é minha variavel
    		// formulario é o id do meu formulario
    		// value é o valor do input
    		// o + na frente transforma em number a string	
    			
    		var kilos  		= +formulario.kilos.value;
    		var metros 		= +formulario.metros.value;
    		var centimetros = +formulario.centimetros.value;
    		
     		// altura
    		var altura = (metros * 100 + centimetros) / 100;
    		 
    		// imc
    		var imc = kilos / (altura * altura);
    		
    		// o metodo toFixed fixa apenas duas casas decimais apos o ponto.
    		formulario.imc.value = imc.toFixed(2);
    		
    		if(imc < 20)
    		{
    			alert('Você esta abaixo do peso!');
    		} 
    		else if(imc >20 && imc <= 25)
    		{
    			alert("Peso Ideal");
    		}
    		else if(imc >25 && imc <= 30)
    		{
    			alert("Sobrepeso");
    		}
    		else if(imc >30 && imc <= 35)
    		{
    			alert("Obesidade Moderada");
    		}
    		else if(imc >35 && imc <= 40)
    		{
    			alert("Obesidade Severa");
    		}
    		else if(imc >40 && imc <= 50)
    		{
    			alert("Obesidade Morbida");
    		}
    		else
    		{
    			alert('Gordo');
    		}
    	}
    </script>
      <fieldset>
          <label for="imc">imc:</label>
        <input name="imc" type="text" disabled="disabled" />
            
        <a href="#" onclick="calcular();">Calcular</a>
          </fieldset>
                
          </div>
          
          
          
           <hr>
           <img src="http://www.ensasport.com/wp-content/uploads/2016/03/IMC-clasificacio%CC%81n.jpg"  width="350" height="200"></img>
           <hr>
                   
       
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">cerrar</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>
  
        

</body>
1</html>



        
