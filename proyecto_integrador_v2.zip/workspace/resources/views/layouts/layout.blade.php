 <!doctype html>
<html lang="en">
  <head>
    <title>Colorlib Medi+</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300, 400, 700" rel="stylesheet">
    <link rel="stylesheet" href="../../assets2/css/bootstrap.css">
    <link rel="stylesheet" href="../../assets2/css/animate.css">
    <link rel="stylesheet" href="../../assets2/css/owl.carousel.min.css">
    <link rel="stylesheet" href="../../assets2/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="../../assets2/css/jquery.timepicker.css">
    <link rel="stylesheet" href="../../assets2/fonts/ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="../../assets2/fonts/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../../assets2/fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="../../assets2/css/style.css">
  </head>
  <body>
 @yield('contenido')	
 
 
    <script src="../../assets2/js/jquery-3.2.1.min.js"></script>
    <script src="../../assets2/js/popper.min.js"></script>
    <script src="../../assets2/js/bootstrap.min.js"></script>
    <script src="../../assets2/js/owl.carousel.min.js"></script>
    <script src="../../assets2/js/bootstrap-datepicker.js"></script>
    <script src="../../assets2/js/jquery.timepicker.min.js"></script>
    <script src="../../assets2/js/jquery.waypoints.min.js"></script>
    <script src="../../assets2/js/main.js"></script>
    
    </body>
	</html>