<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Encuesta2 extends Model
{
    //
}
