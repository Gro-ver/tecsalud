
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="bootstrap410/css/bootstrap.min.css">
    <link rel="stylesheet" href="estilocuestionario.css">
    <script src="main.js"></script>
</head>
<body>

        <div class="contentainer">
        <div class="content">
        <form >
                <table cellpadding="0" cellspacing="0" class="evaluation" >
                <tbody>
                    <tr >
                        <td class="first" width="300" align="left">
                            <img src="./Tu Evaluación Alimentaria_files/icon-cereales-big.png" class="icon">
                            Cereales, tubérculos y sus derivados                    </td>
                    </tr>
                    <tr class="cereales">
                        <td>
                                        
                                
    
    <div class="row">
        <div class="label left">Cereales para desayuno</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db52">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Atoles (cereal cocido)</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db53">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Arroz</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db6c">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Pasta (espagueti, tallarines, coditos)</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db6d">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Burritos, quesadillas</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db54">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Tortillas de maíz o harina</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db4f">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Sandwiches, hamburguesas, perros</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db6b">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Pan integral</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db55">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Pan blanco, bolillo, bollo, pan árabe (pita)</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db56">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Hot cakes, pancakes</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db57">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Chips (papitas, Cheetos<sup>TM</sup>, etc)</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db48">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Palomitas de maíz</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db58">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Galletas saladas</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db59">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Papas, yuca, camote, boniato</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db73">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                                </td>
                    </tr>
                </tbody>
            </table>
    
                <table cellpadding="0" cellspacing="0" class="evaluation" id="ex-table">
                <tbody>
                    <tr class="header frutas">
                        <td class="first" width="300" align="left">
                            <img src="./Tu Evaluación Alimentaria_files/icon-frutas-big.png" class="icon">
                            Frutas y verduras                    </td>
                    </tr>
                    <tr class="frutas">
                        <td>
                                        
                                
    
    <div class="row">
        <div class="label left">Jugos de fruta (naturales, enlatados o congelados)</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db5a">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Frutas frescas</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db4b">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Frutas enlatadas</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db5b">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Coco o leche de coco</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db6e">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Sopa de verduras</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db4d">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Otros verduras: lechuga, tomate, brócoli, zanahoria</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db4e">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Verduras congeladas</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db6f">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Verduras enlatadas</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db70">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                                </td>
                    </tr>
                </tbody>
            </table>
    
                <table cellpadding="0" cellspacing="0" class="evaluation" id="ex-table">
                <tbody>
                    <tr class="header productos">
                        <td class="first" width="300" align="left">
                            <img src="./Tu Evaluación Alimentaria_files/icon-lacteos-big.png" class="icon">
                            Productos lácteos                    </td>
                    </tr>
                    <tr class="productos">
                        <td>
                                        
                                
    
    <div class="row">
        <div class="label left">Quesos</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db3b">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Leche entera, de soya, o sin lactosa</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db44">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Leche semidescremada (1% o 2%)</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db71">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Leche descremada</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db51">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Licuados con leche, batidos o smoothies</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db5c">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Requesón, queso cottage, ricotta</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db45">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Yogur</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db46">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Helados</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db4a">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Pudines, postres con leche</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db47">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                                </td>
                    </tr>
                </tbody>
            </table>
    
                <table cellpadding="0" cellspacing="0" class="evaluation" id="ex-table">
                <tbody>
                    <tr class="header carnes">
                        <td class="first" width="300" align="left">
                            <img src="./Tu Evaluación Alimentaria_files/icon-carnes-big.png" class="icon">
                            Carnes                    </td>
                    </tr>
                    <tr class="carnes">
                        <td>
                                        
                                
    
    <div class="row">
        <div class="label left">Carne de res (carne molida, chuleta)</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db50">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Carne de res magra (filete)</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db72">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Carne de cerdo magra (lomo, filete)</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db69">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Pollo o pavo (asado, al horno o hervido)</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db5e">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Pollo frito, empanizado</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db3c">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Pescado o mariscos</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db5f">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Embutidos (salchicha, salami, jamón)</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db60">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Chorizo, chicharrón</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db3d">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Carne de cerdo (chuletas, costillas)</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db3e">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Vísceras (hígado, sesos, otros)</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db61">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Mantequilla de maní (cacahuate)</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db62">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Maní, almendras, nueces, semillas</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db63">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Huevos o sustitutos de huevo</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db42">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Tofu o sustitutos de carne hechos de soya</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db64">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Fríjoles, habichuelas, garbanzos, lentejas, habas</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db4c">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                                </td>
                    </tr>
                </tbody>
            </table>
    
                <table cellpadding="0" cellspacing="0" class="evaluation" id="ex-table">
                <tbody>
                    <tr class="header grasas">
                        <td class="first" width="300" align="left">
                            <img src="./Tu Evaluación Alimentaria_files/icon-grasas-big.png" class="icon">
                            Grasas y azúcares                    </td>
                    </tr>
                    <tr class="grasas">
                        <td>
                                        
                                
    
    <div class="row">
        <div class="label left">Mayonesa o aderezos para ensaladas</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db3f">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Aguacate</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db5d">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Tocino</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db65">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Crema de leche, queso crema</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db43">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Mantequilla, margarina, manteca vegetal o de cerdo</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db40">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Aceites vegetales (oliva, canola, maíz, maní, etc.)</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db41">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Azúcar de mesa, almíbar, mermelada, miel</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db66">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Quesos grasosos, paté de hígado</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db67">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Pasteles, postres, pan dulce, empanadas</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db49">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Gaseosas, refrescos (regular)</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db68">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                        
                                
    
    <div class="row">
        <div class="label left">Dulces, caramelos, chocolates</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db74">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
                                                </td>
                    </tr>
                </tbody>
            </table>
    
                <table cellpadding="0" cellspacing="0" class="evaluation" id="ex-table">
                <tbody>
                    <tr class="header agua">
                        <td class="first" width="300" align="left">
                            <img src="./Tu Evaluación Alimentaria_files/icon-resultados-aguaybebidas.png" class="icon">
                            Agua                    </td>
                    </tr>
                    <tr class="agua">
                        <td>
                                        
                                
    
    <div class="row">
        <div class="label left">Agua</div>
        <div class="select left">
            <select name="4e821b0fe3f0ed4c5710db6a">
                                <option value="0" selected="selected">Nunca</option>
                                <option value="0.14">1 Por Semana</option>
                                <option value="0.35">2 - 3 Por Semana</option>
                                <option value="0.7">4 - 6 Por Semana</option>
                                <option value="1.5">1 - 2 Por dia</option>
                                <option value="3.5">3 - 4 Por dia</option>
                                <option value="6">5+ Por dia</option>
                        
            </select>
    
    
            <div class="ddown">
                <img src="./Tu Evaluación Alimentaria_files/icon-arrow-dropdown.png" class="arrow">
            </div>
        </div>
    </div>
                
           </td>
           </tr>
           </tbody>
            </table>
    
                
        <a id="continue-button" href="javascript:void(0);" class="md-button">
        <div id="cont-buttons">
        Continúa	</div>
    </a>
    </form>
</div>
</div>
    
</body>
</html>