<?php $__env->startSection('content'); ?>
        <div class="row">
            <section class="content">
                <div class="col-md-8 col-md-offset-2">
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
            <strong>Error!</strong> Revise los campos obligatorios.<br><br>
                <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
        </div>
        
        <?php endif; ?>
        <?php if(Session::has('success')): ?>
        <div class="alert alert-info">
            <?php echo e(Session::get('success')); ?>

        </div>
        <?php endif; ?>
        
        <h1>Realiza tus encuestas</h1>
        <form action="" method="POST" role="form">
            <table>
              <thead>
                <tr>
                    <th>Cereales Tuberculos y sus derivados</th>
                </tr>
              </thead>
              <tbody>
                  <tr>
                    <th name="p1" >Cereales para tu desayuno</th>
                    <th>Desplegable</th>
                </tr>
              </tbody>
            </table>
        </form>
        </div>
        </section>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>