@extends('layouts.header')
@section('content')
        <div class="row">
            <section class="content">
                <div class="col-md-8 col-md-offset-2">
        @if (count($errors) > 0)
            <div class="alert alert-danger">
            <strong>Error!</strong> Revise los campos obligatorios.<br><br>
                <ul>
        @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
                </ul>
        </div>
        
        @endif
        @if(Session::has('success'))
        <div class="alert alert-info">
            {{Session::get('success')}}
        </div>
        @endif
        
        <h1>Realiza tus encuestas</h1>
        <form action="" method="POST" role="form">
            <table>
              <thead>
                <tr>
                    <th>Cereales Tuberculos y sus derivados</th>
                </tr>
              </thead>
              <tbody>
                  <tr>
                    <th name="p1" >Cereales para tu desayuno</th>
                    <th>Desplegable</th>
                </tr>
              </tbody>
            </table>
        </form>
        </div>
        </section>
        </div>
@endsection